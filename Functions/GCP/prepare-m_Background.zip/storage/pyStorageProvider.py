from enum import Enum

# enum to distinguisch amazon and google provider


class pyStorageProvider(Enum):
    AWS = "AWS"
    GCP = "GCP"
