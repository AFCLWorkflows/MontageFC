import json
from subprocess import call
import os
from MontagePy.main import mDiff
from storage.pyStorage import pyStorage
from Inspector import *

"""
This function executes first mDiff followed by mFitplane and uploads
output of mFitplane
return: - filename of mFitplane output
"""
def get_dir_size(path='.'):
    total = 0
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    return total
    
def handler(event):
    
    call('rm -rf /tmp/*', shell=True)
    inspector = Inspector()
    
    bucket_arn = event.json.get('bucket')
    header = event.json.get('header')
    diff_row = json.loads(event.json.get("diff"))
    color_folder = event.json.get('color_folder')
    
    path_wo_filename = 'temp/' + color_folder + '/' + 'proj/'

    first = str(diff_row["first"])
    first_index = str(diff_row["first_index"])
   
    second = str(diff_row["second"])
    second_index = str(diff_row["second_index"])

    first_path = path_wo_filename + first
    first_area_path = first_path[:len(first_path) - 5] + '_area.fits'

    second_path = path_wo_filename + second
    second_area_path = second_path[:len(second_path) - 5] + '_area.fits'

    header_tmp = '/tmp/' + header
    header_path = 'input/' + header

    first_tmp = '/tmp/' + first 
    first_area_tmp = '/tmp/' + first_area_path.split('/')[-1]   #split to only get filename
    second_tmp = '/tmp/' + second
    second_area_tmp = '/tmp/' + second_area_path.split('/')[-1]
    
    mDiff_output = 'diff.' + first_index.zfill(6) + '.' + second_index.zfill(6) + '.fits'
    mDiff_output_tmp = '/tmp/' + mDiff_output
    
    pyStorage.create_cred_file(
        aws_access_key_id = event.json.get('credentials')[0],
        aws_secret_access_key = event.json.get('credentials')[1],
        aws_session_token = event.json.get('credentials')[2],
        gcp_client_email = event.json.get('credentials')[3],
        gcp_private_key = event.json.get('credentials')[4],
        gcp_project_id = event.json.get('credentials')[5]
        )
    
    inspector.addTimeStamp("StartDownload1")
    pyStorage.copy(bucket_arn + '/' + header_path, header_tmp)
    pyStorage.copy(bucket_arn + '/' + first_area_path, first_area_tmp)
    pyStorage.copy(bucket_arn + '/' + second_area_path, second_area_tmp)
    pyStorage.copy(bucket_arn + '/' + first_path, first_tmp)
    pyStorage.copy(bucket_arn + '/' + second_path, second_tmp)
    inspector.addTimeStamp("EndDownload1")
    size_download = get_dir_size('/tmp/')
    
    rtn = mDiff(first_tmp, second_tmp, mDiff_output_tmp, header_tmp)
    
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    dt = {
        'DT': download_time/1000,
        'files': 5,
        'total_size': size_download
    }
    
    if rtn['status']=='1' and str(rtn['msg'])=='b\"Images don\'t overlap\"':
        inspector.finish()
    
        ut = {
            'UT': 0,
            'files': 0,
            'total_size': 0
        }
    
        runtime_data = {
            'download': dt,
            'upload': ut,
            'ET': inspector.getAttribute('runtime')/1000,
            'URL': bucket_arn
        }
        
        return {
        'statusCode': 200,
        'mDiff' : "Skipped because no overlap",
        'runtime_data' : runtime_data,
        'firstIndex' : first_index,
        'firstIndex' : second_index
    }
    
    filename_fit = 'fit.' + first_index.zfill(6) + '.' + second_index.zfill(6) + '.txt'
    filename_tmp = '/tmp/'+ filename_fit
        
    rtn_fit = call(["/workspace/bin/mFitplane", "-s", filename_tmp, mDiff_output_tmp])
    
    if rtn_fit==1:
        file = open(filename_tmp, "r")
        file_contents = file.read()
        file.close()
        return{
            'statusCode' : 400,
            'mFitplane error: ' : file_contents,
            'color_folder': color_folder
        }
    
    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy(filename_tmp, bucket_arn + '/temp/' + color_folder + '/' + 'diffs/{}'.format(filename_fit))
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    
    inspector.finish()
    
    ut = {
        'UT': upload_time/1000,
        'files': 1,
        'total_size': os.path.getsize(filename_tmp)
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn
    }
    
    return {
        'statusCode': 200,
        'fit.txt' : filename_fit,
        'color_folder': color_folder,
        'credentials': event.json.get('credentials'),
        'runtime_data' : runtime_data
    }

