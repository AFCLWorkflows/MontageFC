import json
from MontagePy.main import mImgtbl, mOverlaps
import boto3
import os
import pandas
from storage.pyStorage import pyStorage
from subprocess import call
from google.cloud import storage
"""
This function is required for the following parallel function mDiffFit.
Generates a list of differences from diffs.tbl. Uploads pimages.tbl and diffs.tbl
return: - list of diff rows
        - number of files
"""

def handler(event):

    call('rm -rf /tmp/*', shell=True)
    os.mkdir('/tmp/input')
    
    bucket_arn = event.json.get('bucket')
    bucket_name = event.json.get('bucket').split("gs://")[1]
    color_folder = event.json.get('color_folder')
    header = event.json.get('header')
    header_tmp = '/tmp/' + header
    header_path = 'input/' + header
    storage_client = storage.Client()
    
    pyStorage.create_cred_file(
        aws_access_key_id = event.json.get('credentials')[0],
        aws_secret_access_key = event.json.get('credentials')[1],
        aws_session_token = event.json.get('credentials')[2],
        gcp_client_email = event.json.get('credentials')[3],
        gcp_private_key = event.json.get('credentials')[4],
        gcp_project_id = event.json.get('credentials')[5]
        )
        
    pyStorage.copy(bucket_arn + '/' + header_path, header_tmp)
    count_files_download = 1
    
    for files in storage_client.list_blobs(bucket_name, prefix='input/' + color_folder + '/'):
        if files.name[-10:] == '_area.fits':
            	continue
        pyStorage.copy(bucket_arn + "/" + files.name, "/tmp/input/{}".format(files.name.split("input/" + color_folder + "/")[1]))
        

    rtn = mImgtbl('/tmp/input', '/tmp/images.tbl')
    
    if rtn['status']=='1':
        return{
            	'statusCode' : 400,
            	'mImgtbl error: ' : rtn['msg']
        }
        
    rtn_mDAG = call(["/workspace/bin/mDAGTbls", "/tmp/images.tbl", header_tmp, "/tmp/rimages.tbl", "/tmp/pimages.tbl", "/tmp/cimages.tbl"])
    
    rtn = mOverlaps("/tmp/pimages.tbl", "/tmp/diffs.tbl")
    
    if rtn['status']=='1':
        return{
            'statusCode' : 400,
            'mOverlaps error: ' : rtn['msg']
        } 
        
    ###########pimages
    with open('/tmp/pimages.tbl', 'r') as file:
        filedata = file.read()
    # Replace the target string
    filedata = filedata.replace('p2mass', '/tmp/proj/2mass')
    filedata = filedata.replace('                               file', '                                        file')
    filedata = filedata.replace('                               char', '                                        char')

    # Write the file out again
    with open('/tmp/pimages.tbl', 'w') as file:
        file.write(filedata)
        
    ###########diffs
    with open('/tmp/diffs.tbl', 'r') as file:
        filedata = file.read()
    # Replace the target string
    filedata = filedata.replace('p2mass', '/tmp/proj/2mass')
    filedata = filedata.replace('                              plus ', '                                       plus ')
    filedata = filedata.replace('                             minus ', '                                      minus ')
    filedata = filedata.replace('                              char ', '                                       char ')

    # Write the file out again
    with open('/tmp/diffs.tbl', 'w') as file:
        file.write(filedata)
        
    diff_table = pandas.read_table('/tmp/diffs.tbl', skiprows=2, delim_whitespace=True, header=None, index_col=None)
    diff_rows = []

    for row in diff_table.values:
        diff_row = json.dumps({
            "first_index": row[0],
            "second_index": row[1],
            "first": row[2].split('/tmp/proj/')[1],
            "second": row[3].split('/tmp/proj/')[1],
        })
        diff_rows.append(diff_row)
       
    pyStorage.copy('/tmp/pimages.tbl', bucket_arn + '/temp/' + color_folder + '/' + 'pimages.tbl')
    pyStorage.copy('/tmp/diffs.tbl', bucket_arn + '/temp/' + color_folder + '/' + 'diffs.tbl')
    
    return {
        'statusCode': 200,
        'diff_rows': diff_rows,
        'number': len(diff_table),
        'bucket' : bucket_arn,
        'header' : event.json.get('header'),
        'color_folder' : color_folder,
        'credentials': event.json.get('credentials')
    }

