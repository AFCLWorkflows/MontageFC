import json
from storage.pyStorage import pyStorage
from Inspector import *

"""
This function creates color_folders.txt which is needed in function mViewer and 
to define how many times the parallel loop createMosaic has to be executed
return:  
        - number of elements in color_folders
        
return for every function: 
                    - credentials as collection
                    - color folders as collection
                    - bucket-arn
                    - header
"""

def handler(event):
    
    inspector = Inspector()

    bucket_arn = event.json.get('bucket')
    filename_tmp = '/tmp/color_folders'
    color_folders = event.json.get('color_folders')

    file = open(filename_tmp, "w")
    
    if len(event.json.get('color_folders')) == 1:
        color_folders = event.json.get('color_folders')[0]
        file.write("%s\n" % color_folders)
    else:
        for item in color_folders:
            file.write("%s\n" % item)
    
    file.close()

    pyStorage.create_cred_file(
        aws_access_key_id = event.json.get('aws_access_key_id'),
        aws_secret_access_key = event.json.get('aws_secret_access_key'),
        aws_session_token = event.json.get('aws_session_token'),
        gcp_client_email = event.json.get('gcp_client_email'),
        gcp_private_key = event.json.get('gcp_private_key'),
        gcp_project_id = event.json.get('gcp_project_id')
        )

    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy(filename_tmp, bucket_arn + '/temp/color_folders.txt')
    
    inspector.addTimeStamp("EndUpload1")
    
    credentials = [event.json.get('aws_access_key_id'), 
                    event.json.get('aws_secret_access_key'), 
                    event.json.get('aws_session_token'),
                    event.json.get('gcp_client_email'),
                    event.json.get('gcp_private_key'),
                    event.json.get('gcp_project_id')]

    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')

    inspector.finish()
    
    dt = {
        'DT': 0,
        'files': 0,
        'total_size': 0
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 1,
        'total_size': os.path.getsize(filename_tmp)
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn
    }
    
    return {
        'statusCode': 200,
        'number' : len(color_folders),
        'bucket' : bucket_arn,
        'header' : event.json.get('header'),
        'color_folders' : color_folders,
        'credentials' : credentials,
        'runtime_data' : runtime_data
    }
