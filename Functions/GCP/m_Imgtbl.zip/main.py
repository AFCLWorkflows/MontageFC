import json
from MontagePy.main import mImgtbl
import os
from subprocess import call
from storage.pyStorage import pyStorage
from google.cloud import storage
from Inspector import *
"""
This function exercutes mBackground to create the cimages.tbl table of
the corrected fits files located in <bucket-arn>/temp/[color_folder]correct
"""
def get_dir_size(path='.'):
    total = 0
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    return total
    
def handler(event):
    
    call('rm -rf /tmp/*', shell=True)
    os.mkdir('/tmp/images')
    inspector = Inspector()
   
    bucket_arn = event.json.get('bucket')
    bucket_name = event.json.get('bucket').split("gs://")[1]
    color_folder = event.json.get('color_folder')
    
    storage_client = storage.Client()

    pyStorage.create_cred_file(
        aws_access_key_id = event.json.get('credentials')[0],
        aws_secret_access_key = event.json.get('credentials')[1],
        aws_session_token = event.json.get('credentials')[2],
        gcp_client_email = event.json.get('credentials')[3],
        gcp_private_key = event.json.get('credentials')[4],
        gcp_project_id = event.json.get('credentials')[5]
        )
    
    count_files_download = 0
    inspector.addTimeStamp("StartDownload1")
    
    for files in storage_client.list_blobs(bucket_name, prefix='temp/' + color_folder + '/correct/'):
    	file_name = files.name.split("correct/")[1]
    	pyStorage.copy(bucket_arn + '/temp/' + color_folder + '/correct/{}'.format(file_name), '/tmp/images/{}'.format(file_name))
    	count_files_download = count_files_download + 1
        
    inspector.addTimeStamp("EndDownload1")
    
    size_download = get_dir_size('/tmp/')
    rtn = mImgtbl('/tmp/images', '/tmp/cimages.tbl')

    if rtn['status']=='1':
    	return{
            'statusCode' : 400,
            'mImgtbl error: ' : rtn['msg']
        }
    
    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy('/tmp/cimages.tbl', bucket_arn + '/temp/' + color_folder + '/cimages.tbl')
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': count_files_download,
        'total_size': size_download
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 1,
        'total_size': os.path.getsize('/tmp/cimages.tbl')
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn
    }
    
    
    return{
        'statusCode': 200,
        'bucket' : bucket_arn,
        'header' : event.json.get('header'),
        'color_folder' : color_folder,
        'credentials': event.json.get('credentials'),
        'runtime_data' : runtime_data
    }
