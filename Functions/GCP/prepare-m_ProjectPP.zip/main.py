import json
from google.cloud import storage

"""
This function is required for the following parallel function mProjectPP 
to get the input file names
return: - list of file names which are located in <bucket-arn>/input/color_folder/
        - number of files
"""

def handler(event):

    bucket_name = event.json.get('bucket').split("gs://")[1]
    storage_client = storage.Client()
    color_folder = event.json.get('color_folder')
    
    file_names = []

    #input files needs to be located at <bucket-name>/input
    for files in storage_client.list_blobs(bucket_name, prefix="input/"+ color_folder + "/"):
        file_name = files.name.split("input/")[1]
        if file_name[-5:] == '.fits' and file_name != "" :
            file_names.append(file_name)
    
    return {
        'statusCode': 200,
        'filenames': file_names,
        'number' : len(file_names),
        'bucket' :  event.json.get('bucket'),
        'header' : event.json.get('header'),
        'color_folder' : color_folder,
        'credentials' : event.json.get('credentials')
    }
