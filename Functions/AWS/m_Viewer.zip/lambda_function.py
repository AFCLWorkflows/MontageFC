import json
from MontagePy.main import mViewer
from storage.pyStorage import pyStorage
import os
from Inspector import *
from subprocess import call

"""
This function executes mViewer to create the mosaic.png file and uploads
it to <bucket-arn>/output/
"""
def get_dir_size(path='.'):
    total = 0
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    return total

def lambda_handler(event, context):
    
    call('rm -rf /tmp/*', shell=True)
    inspector = Inspector()
    inspector.inspectAll()
    bucket_arn = event['bucket']
    
    pyStorage.create_cred_file(
        aws_access_key_id = event['credentials'][0],
        aws_secret_access_key = event['credentials'][1],
        aws_session_token = event['credentials'][2],
        gcp_client_email = event['credentials'][3],
        gcp_private_key = event['credentials'][4],
        gcp_project_id = event['credentials'][5]
        )
    
    inspector.addTimeStamp("StartDownload1")
    
    pyStorage.copy(bucket_arn + '/temp/color_folders.txt', '/tmp/color_folders.txt')
    
    inspector.addTimeStamp("EndDownload1")
    
    color_folders = []

    with open('/tmp/color_folders.txt', 'r') as fp:
        for line in fp:
            color = line[:-1]
            color_folders.append(color)
    
    inspector.addTimeStamp("StartDownload2")
    for color in color_folders:
        pyStorage.copy(bucket_arn + '/output/mosaic_' + color + '.fits' , '/tmp/mosaic_' + color + '.fits')
          
    inspector.addTimeStamp("EndDownload2")
    
    size_download = get_dir_size('/tmp/')
    
    rtn = 0
    
    if len(color_folders) == 3:
        rtn = mViewer("-red /tmp/mosaic_red.fits -1s 99.999% gaussian-log -green /tmp/mosaic_green.fits -1s 99.999% gaussian-log -blue /tmp/mosaic_blue.fits -1s 99.999% gaussian-log -out /tmp/mosaic.png", "/tmp/mosaic.png", mode=2)
        
    elif len(color_folders) == 1:
        rtn = mViewer("-ct 1 -gray /tmp/mosaic_gray.fits -2s max gaussian-log -out /tmp/mosaic.png", "/tmp/mosaic.png", mode=2)
        
    else:
        return{
        'statusCode': 400,
        'error message': "color_folders must have 1 or 3 entries"
    } 

    if rtn['status']=='1':
        return{
            'statusCode' : 400,
            'mViewer error: ' : rtn['msg']
        }
    
    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy('/tmp/mosaic.png', bucket_arn + '/output/mosaic.png')
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1') + inspector.getAttribute('EndDownload2') - inspector.getAttribute('StartDownload2')
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': len(color_folders),
        'total_size': size_download
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 1,
        'total_size': os.path.getsize('/tmp/mosaic.png')
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn,
        'memory' : inspector.getAttribute('functionMemory')
    }

    return{
        'statusCode': 200,
        'final picture': "mosaic.png",
        'runtime_data' : runtime_data
    } 
        