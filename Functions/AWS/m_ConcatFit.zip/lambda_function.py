import json
import os
import boto3
from subprocess import call
from storage.pyStorage import pyStorage
from Inspector import *

"""
This function is required to combine all diffs into fits.tbl which is needed
by mBgModel. Uploads fits.tbl to <bucket-arn>/temp/[color_folder]/
"""
def get_dir_size(path='.'):
    total = 0
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    return total
    
def lambda_handler(event, context):

    call('rm -rf /tmp/*', shell=True)
    inspector = Inspector()
    inspector.inspectAll()
    os.mkdir('/tmp/diffs')

    s3= boto3.client('s3')
    bucket_arn = event['bucket']
    bucket_name = event['bucket'][len("arn:aws:s3:::"):].split("/")[0]
    color_folder = event['color_folder']

    pyStorage.create_cred_file(
        aws_access_key_id = event['credentials'][0],
        aws_secret_access_key = event['credentials'][1],
        aws_session_token = event['credentials'][2],
        gcp_client_email = event['credentials'][3],
        gcp_private_key = event['credentials'][4],
        gcp_project_id = event['credentials'][5]
        )

    inspector.addTimeStamp("StartDownload1")
    
    pyStorage.copy(bucket_arn + '/temp/' + color_folder + '/' + 'pimages.tbl', '/tmp/pimages.tbl')
    pyStorage.copy(bucket_arn + '/temp/' + color_folder + '/' + 'diffs.tbl', '/tmp/diffs/diffs.tbl')
    count_files_download = 2
    
    inspector.addTimeStamp("EndDownload1")

    rtn = call(["/opt/bin/mStatFile", "/tmp/diffs/"])
    
    if rtn != 0:
        return{
            'statusCode' : 400,
            'mStatFile error: ' : 'Invalid diffs.tbl'
        }
    
    #response = s3.list_objects_v2(
    #    Bucket=bucket_name, Prefix='temp/' + color_folder + '/' + 'diffs/')
        
    #s3_files = response["Contents"]
    
    #inspector.addTimeStamp("StartDownload2")
    
    #for s3_file in s3_files:
        #Key: /temp/color_folder/diffs/file_name
    #    pyStorage.copy(bucket_arn + '/' + s3_file["Key"], '/tmp/{}'.format(s3_file["Key"].split('temp/' + color_folder + '/')[1]))
    #    count_files_download = count_files_download + 1
        
    #inspector.addTimeStamp("EndDownload2")
    
    
    #################
    paginator = s3.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=bucket_name, Prefix='temp/' + color_folder + '/' + 'diffs/')
    
    inspector.addTimeStamp("StartDownload2")

    for page in pages:
        if "Contents" in page:
            for obj in page['Contents']:
                #Key: /temp/color_folder/diffs/file_name
                pyStorage.copy(bucket_arn + '/' + obj["Key"], '/tmp/{}'.format(obj["Key"].split('temp/' + color_folder + '/')[1]))
                count_files_download = count_files_download + 1
                
    inspector.addTimeStamp("EndDownload2")
    
    ##################

        
    size_download = get_dir_size('/tmp/') - os.path.getsize('/tmp/diffs/statfile.tbl')
    
    status_file_tmp = '/tmp/status_file.txt'
    rtn = call(["/opt/bin/mConcatFit", "-s", status_file_tmp, "/tmp/diffs/statfile.tbl", "/tmp/diffs/fits.tbl", "/tmp/diffs/"])
    
    if rtn == 1:
        file = open(status_file_tmp, "r")
        file_contents = file.read()
        file.close()
        return{
            'statusCode' : 400,
            'mConcatFit error: ' : file_contents
        }

    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy('/tmp/diffs/fits.tbl', bucket_arn + '/temp/' + color_folder + '/fits.tbl')
    pyStorage.copy('/tmp/diffs/statfile.tbl', bucket_arn + '/temp/' + color_folder + '/stafile.tbl')
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1') + (inspector.getAttribute('EndDownload2') - inspector.getAttribute('StartDownload2'))
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': count_files_download,
        'total_size': size_download
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 2,
        'total_size': (os.path.getsize('/tmp/diffs/statfile.tbl') + os.path.getsize('/tmp/diffs/fits.tbl'))
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn,
        'memory' : inspector.getAttribute('functionMemory')
    }

    return {
        'statusCode': 200,
        'bucket' : bucket_arn,
        'header' : event['header'],
        'color_folder' : color_folder,
        'credentials':event['credentials'],
        'runtime_data' : runtime_data
    }
