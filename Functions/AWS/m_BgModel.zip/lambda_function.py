import logging
import json
from MontagePy.main import mBgModel
import os
from storage.pyStorage import pyStorage
from Inspector import *

"""
This function executes mBgModel and uploads corrections.tbl to 
<bucket-arn>/temp/[color_folder]/
"""

def lambda_handler(event, context):
    
    inspector = Inspector()
    
    bucket_arn = event['bucket']
    color_folder = event['color_folder']

    filename_pimages = 'temp/' + color_folder + '/pimages.tbl'
    filename_fits = 'temp/' + color_folder + '/fits.tbl'

    pimages_tmp = '/tmp/pimages.tbl'
    fits_tmp = '/tmp/fits.tbl'

    filename_corrections = 'temp/' + color_folder + '/corrections.tbl'
    corrections_tmp = '/tmp/corrections.tbl'
    
    pyStorage.create_cred_file(
        aws_access_key_id = event['credentials'][0],
        aws_secret_access_key = event['credentials'][1],
        aws_session_token = event['credentials'][2],
        gcp_client_email = event['credentials'][3],
        gcp_private_key = event['credentials'][4],
        gcp_project_id = event['credentials'][5]
        )
    
    inspector.addTimeStamp("StartDownload1")
    
    pyStorage.copy(bucket_arn + '/' + filename_pimages, pimages_tmp)
    pyStorage.copy(bucket_arn + '/' + filename_fits, fits_tmp)
    
    inspector.addTimeStamp("EndDownload1")

    rtn = mBgModel(pimages_tmp, fits_tmp, corrections_tmp)
    
    if rtn['status']=='1':
        return{
            'statusCode' : 400,
            'mBgModel error: ' : rtn['msg']
        }

    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy(corrections_tmp, bucket_arn + '/' + filename_corrections)
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': 2,
        'total_size': (os.path.getsize(pimages_tmp) + os.path.getsize(fits_tmp))
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 1,
        'total_size': os.path.getsize(corrections_tmp)
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn
    }

    return {
        'statusCode': 200,
        'bucket' : bucket_arn,
        'header' : event['header'],
        'color_folder' : color_folder,
        'credentials': event['credentials'],
        'runtime_data' : runtime_data
    }