import json
from MontagePy.main import mImgtbl
import boto3
import os
from subprocess import call
from storage.pyStorage import pyStorage
from Inspector import *

"""
This function exercutes mBackground to create the cimages.tbl table of
the corrected fits files located in <bucket-arn>/temp/[color_folder]correct
"""
def get_dir_size(path='.'):
    total = 0
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    return total

def lambda_handler(event, context):
    
    call('rm -rf /tmp/*', shell=True)
    os.mkdir('/tmp/images')
    inspector = Inspector()
    inspector.inspectAll()
   
    s3_resource = boto3.resource('s3')
    
    color_folder = event['color_folder']
    bucket_arn = event['bucket']
    bucket_name = event['bucket'][len("arn:aws:s3:::"):].split("/")[0]
    bucket = s3_resource.Bucket(bucket_name) 

    pyStorage.create_cred_file(
        aws_access_key_id = event['credentials'][0],
        aws_secret_access_key = event['credentials'][1],
        aws_session_token = event['credentials'][2],
        gcp_client_email = event['credentials'][3],
        gcp_private_key = event['credentials'][4],
        gcp_project_id = event['credentials'][5]
        )
    
    count_files_download = 0
    inspector.addTimeStamp("StartDownload1")
    
    for file in bucket.objects.filter(Prefix='temp/' + color_folder + '/correct/'):
        file_name = file.key.split("correct/")[1]
        pyStorage.copy(bucket_arn + '/temp/' + color_folder + '/correct/{}'.format(file_name), '/tmp/images/{}'.format(file_name))
        count_files_download = count_files_download + 1
        
    inspector.addTimeStamp("EndDownload1")
    
    size_download = get_dir_size('/tmp/')
  
    rtn = mImgtbl('/tmp/images', '/tmp/cimages.tbl')

    if rtn['status']=='1':
        return{
            'statusCode' : 400,
            'mImgtbl error: ' : rtn['msg']
        }
    
    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy('/tmp/cimages.tbl', bucket_arn + '/temp/' + color_folder + '/cimages.tbl')
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': count_files_download,
        'total_size': size_download
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 1,
        'total_size': os.path.getsize('/tmp/cimages.tbl')
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn,
        'memory' : inspector.getAttribute('functionMemory')
    }
    
    return{
        'statusCode': 200,
        'bucket' : bucket_arn,
        'header' : event['header'],
        'color_folder' : color_folder,
        'credentials': event['credentials'],
        'runtime_data' : runtime_data
    }